// +build coveragemain

package main

import (
	"testing"
)

func TestRunMainForCoverage(t *testing.T) {
	main()
}
