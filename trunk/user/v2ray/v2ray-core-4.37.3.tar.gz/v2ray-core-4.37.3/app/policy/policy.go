// Package policy is an implementation of policy.Manager feature.
package policy

//go:generate go run github.com/v2fly/v2ray-core/v4/common/errors/errorgen
