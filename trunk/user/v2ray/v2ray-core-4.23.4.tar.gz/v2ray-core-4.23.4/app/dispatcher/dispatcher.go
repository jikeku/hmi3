// +build !confonly

package dispatcher

//go:generate errorgen
