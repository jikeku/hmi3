package command

//go:generate errorgen
