// Package dns is an implementation of core.DNS feature.
package dns

//go:generate errorgen
