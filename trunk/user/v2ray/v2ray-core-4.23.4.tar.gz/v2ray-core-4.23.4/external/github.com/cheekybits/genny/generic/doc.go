// Package generic contains the generic marker types.
package generic
